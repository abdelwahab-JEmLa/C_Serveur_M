package com.example.serveurecherielhanaaebeljemla.Models

import com.example.Models.AppSettingsSaverModel
import com.example.Models.ClientsDataBase
import com.example.Models.DiviseurDeDisplayProductForEachClient
import com.example.Models.ProductsCategoriesDataBase
import com.example.Models.ProductsDataBase

/**
 * UI State that represents Screen
 **/
data class UiStat(
    val appSettingsSaverModel: List<AppSettingsSaverModel> = emptyList(),
    val productsDataBase: List<ProductsDataBase> = emptyList(),
    val clientsDataBase: List<ClientsDataBase> = emptyList(),
    val diviseurDeDisplayProductForEachClient: List<DiviseurDeDisplayProductForEachClient> = emptyList(),
    val productsCategoriesDataBase: List<ProductsCategoriesDataBase> = emptyList(),

    val isLoading: Boolean = true,
    val error: String? = null,
    val isInitialized: Boolean = false
)



