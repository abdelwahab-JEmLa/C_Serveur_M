package com.example.Packages.P1

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import coil.size.Size
import com.example.c_serveur.R
import java.io.File

@Composable
internal fun DisplayeImageById(
    modifier: Modifier = Modifier,
    idArticle: Long,
    index: Int = 0,
    reloadKey: Any = Unit,
    contentDescription: String? = null
) {
    val context = LocalContext.current

    // Base path for storing images
    val baseImagePath = "/storage/emulated/0/Abdelwahab_jeMla.com/IMGs/BaseDonne/${idArticle}_${index + 1}"

    // Supported image extensions
    val supportedExtensions = listOf("jpg", "jpeg", "png", "webp")

    // Find the first existing image file
    val imageExist = remember(reloadKey, idArticle, index) {
        supportedExtensions.firstNotNullOfOrNull { _ ->
            supportedExtensions.map { ext ->
                File("$baseImagePath.$ext")
            }.firstOrNull { file ->
                file.exists()
            }?.absolutePath
        }
    }

    // Determine the image source (local file or default placeholder)
    val imageSource = imageExist ?: R.drawable.ic_launcher_background

    // Create an image request with additional configuration
    val painter = rememberAsyncImagePainter(
        model = ImageRequest.Builder(context)
            .data(imageSource)
            .size(Size.ORIGINAL)
            .crossfade(true)
            .listener(
                onStart = { _ ->
                    Log.d("ImageLoading", "Started loading image for article $idArticle")
                },
                onError = { _, result ->
                    Log.e("ImageLoading", "Error loading image for article $idArticle: ${result.throwable.message}")
                }
            )
            .build()
    )

    // Display the image
    Image(
        painter = painter,
        contentDescription = contentDescription ?: "Article Image $idArticle",
        modifier = modifier.fillMaxSize(),
        contentScale = ContentScale.Crop,
        alignment = Alignment.Center
    )
}

// Utility function to check if an image exists for an article
fun checkArticleImageExists(
    idArticle: Long,
    index: Int = 0
): Boolean {
    val baseImagePath = "/storage/emulated/0/Abdelwahab_jeMla.com/IMGs/BaseDonne/${idArticle}_${index + 1}"
    val supportedExtensions = listOf("jpg", "jpeg", "png", "webp")

    return supportedExtensions.any { extension ->
        File("$baseImagePath.$extension").exists()
    }
}
