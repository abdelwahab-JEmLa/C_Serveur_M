package com.example.clientjetpack.Modules

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Upsert
import com.example.Models.AppSettingsSaverModel
import com.example.Models.ClientsDataBase
import com.example.Models.DiviseurDeDisplayProductForEachClient
import com.example.Models.ProductsCategoriesDataBase
import com.example.Models.ProductsDataBase
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductsCategoriesDataBaseDao {

    @Query("SELECT COUNT(*) FROM ProductsCategoriesDataBase")
    suspend fun count(): Int

    @Query("SELECT * FROM ProductsCategoriesDataBase")
    fun getAllFlow(): Flow<List<ProductsCategoriesDataBase>>

    @Query("SELECT * FROM ProductsCategoriesDataBase")
    suspend fun getAll(): List<ProductsCategoriesDataBase>


    @Upsert
    suspend fun upsert(item: ProductsCategoriesDataBase)

    @Update
    suspend fun update(item: ProductsCategoriesDataBase)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(list: ProductsCategoriesDataBase)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ProductsCategoriesDataBase>)

    @Upsert
    suspend fun upsertAll(categories: List<ProductsCategoriesDataBase>)

    @Delete
    suspend fun delete(item: ProductsCategoriesDataBase)

    @Query("DELETE FROM ProductsCategoriesDataBase")
    suspend fun deleteAll()
}

@Dao
interface DiviseurDeDisplayProductForEachClientDao {

    @Query("SELECT COUNT(*) FROM DiviseurDeDisplayProductForEachClient")
    suspend fun count(): Int

    @Query("SELECT * FROM DiviseurDeDisplayProductForEachClient")
    fun getAllFlow(): Flow<List<DiviseurDeDisplayProductForEachClient>>

    @Query("SELECT * FROM DiviseurDeDisplayProductForEachClient")
    suspend fun getAll(): List<DiviseurDeDisplayProductForEachClient>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: DiviseurDeDisplayProductForEachClient)

    @Update
    suspend fun update(item: DiviseurDeDisplayProductForEachClient)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(list: DiviseurDeDisplayProductForEachClient)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<DiviseurDeDisplayProductForEachClient>)

    @Delete
    suspend fun delete(item: DiviseurDeDisplayProductForEachClient)

    @Query("DELETE FROM DiviseurDeDisplayProductForEachClient")
    suspend fun deleteAll()

    @Upsert
    suspend fun upsertAll(categories: List<ProductsCategoriesDataBase>)

}

@Dao
interface ClientsDataBaseDao {
    @Query("SELECT COUNT(*) FROM ClientsDataBase")
    suspend fun count(): Int

    @Query("SELECT * FROM ClientsDataBase")
    fun getAllFlow(): Flow<List<ClientsDataBase>>

    @Query("SELECT * FROM ClientsDataBase")
    suspend fun getAll(): List<ClientsDataBase>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ClientsDataBase)

    @Update
    suspend fun update(item: ClientsDataBase)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(list: List<ClientsDataBase>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ClientsDataBase>)

    @Delete
    suspend fun delete(item: ClientsDataBase)

    @Query("DELETE FROM ClientsDataBase")
    suspend fun deleteAll()

}

@Dao
interface ProductsDataBaseDao {

    @Query("SELECT COUNT(*) FROM ProductsDataBase")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM ProductsDataBase")
    suspend fun getCount(): Int

    @Query("SELECT * FROM ProductsDataBase")
    fun getAllFlow(): Flow<List<ProductsDataBase>>

    @Query("SELECT * FROM ProductsDataBase")
    suspend fun getAll(): List<ProductsDataBase>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ProductsDataBase)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(list: List<ProductsDataBase>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ProductsDataBase>)

    @Delete
    suspend fun delete(item: ProductsDataBase)

    @Query("DELETE FROM ProductsDataBase")
    suspend fun deleteAll()
    @Upsert
    suspend fun upsertAll(categories: List<ProductsCategoriesDataBase>)

}



@Dao
interface AppSettingsSaverModelDao {
    @Query("SELECT * FROM AppSettingsSaverModel")
    fun getAllFlow(): Flow<List<AppSettingsSaverModel>>

    @Query("SELECT * FROM AppSettingsSaverModel")
    suspend fun getAll(): List<AppSettingsSaverModel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: AppSettingsSaverModel)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(list: List<AppSettingsSaverModel>)

    @Delete
    suspend fun delete(item: AppSettingsSaverModel)

    @Query("DELETE FROM AppSettingsSaverModel")
    suspend fun deleteAll()

}





