package com.example.Main.MainScreen

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditScore
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.Main.StartFragment.StartFragment
import com.example.Main.StartFragment.StartFragmentDestination
import com.example.Packages.P1.ClientProductsDisplayerStatsDestination
import com.example.Packages.P1.ClientProductsDisplayerStatsFragment
import com.example.c_serveur.AppViewModels

@Composable
fun AppNavHost(
    navController: NavHostController,
    modifier: Modifier = Modifier,
    appViewModels: AppViewModels,
) {

    Box(modifier = modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = Screen.StartFragment.route,
            modifier = Modifier.fillMaxSize()
        ) {

            composable(StartFragmentDestination().route) {
                StartFragment(appViewModels.startFragmentViewModel)
            }

            composable(ClientProductsDisplayerStatsDestination().route) {
                ClientProductsDisplayerStatsFragment(appViewModels.clientProductsDisplayerStatsViewModel)
            }
        }
    }
}
sealed class Screen(
    val route: String,
    val icon: ImageVector,
    val title: String,
    val color: Color
) {
    data object StartFragment : Screen(
        route = "startFragment",
        icon = Icons.Default.Home,
        title = "start Fragment",
        color = Color(0xFF2196F3)
    )
    data object ClientProductsDisplayerStatsFragment : Screen(
        route = "ClientProductsDisplayerStatsFragment",
        icon = Icons.Default.CreditScore,
        title = "ClientProductsDisplayerStatsFragment",
        color = Color(0xFF2196F3)
    )
}

// Update NavigationItems to include the new screen
object NavigationItems {
    fun getItems() = listOf(
        Screen.StartFragment ,
        Screen.ClientProductsDisplayerStatsFragment

    )
}




